//
//  Environment.swift
//  Gymondo
//
//  Created by psagc on 19/01/24.
//

import Foundation

class Environment {
    
    class var BASEURL: String {
        return "https://wger.de/api/v2"
    }
}

//
//  Gymondo.h
//  Gymondo
//
//  Created by psagc on 19/01/24.
//

#import <Foundation/Foundation.h>

//! Project version number for Gymondo.
FOUNDATION_EXPORT double GymondoVersionNumber;

//! Project version string for Gymondo.
FOUNDATION_EXPORT const unsigned char GymondoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Gymondo/PublicHeader.h>



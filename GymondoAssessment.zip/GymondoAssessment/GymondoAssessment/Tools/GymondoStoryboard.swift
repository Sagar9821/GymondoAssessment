//
//  GymondoStoryboard.swift
//  GymondoAssessment
//
//  Created by psagc on 19/01/24.
//

import UIKit

public struct GymondoStoryboard {
    public static var exercise: UIStoryboard {
        UIStoryboard(name: "Excercise", bundle: nil)
    }
}
